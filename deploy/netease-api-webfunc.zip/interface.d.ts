export interface RequestBaseConfig {
  cookie?: string
  realIP?: string // IPv4/IPv6 filled in X-Real-IP
  proxy?: string // HTTP proxy
  randomCNIP?: boolean // Whether to use a random Chinese IP address filled in X-Real-IP
}

export interface MultiPageConfig {
  limit?: string | number
  offset?: string | number
}

export interface ImageUploadConfig {
  imgFile: {
    name: string
    data: string | Buffer
  }
  imgSize?: number
  imgX?: number
  imgY?: number
}

export interface APIBaseResponse {
  code: number
  cookie: string
  [index: string]: unknown
}

export interface Response<Body = APIBaseResponse> {
  status: number // The Http Response Code
  body: Body // API Response body
  cookie: string[]
}

export const enum SubAction {
  sub = 1,
  unsub = 0,
}

export function ad_get(
  params: { type_ids?: string } & RequestBaseConfig,
): Promise<Response>

export function ad_listening_rights(
  params: RequestBaseConfig,
): Promise<Response>

export function ad_listening_rights_gain(
  params: {
    reqUid?: string
    uid?: string | number
    exposureTime?: string | number
    clickTime?: string | number
    extraRightsType?: string | number
    playContinuously?: boolean | string
    source?: string | number
    creativeType?: string | number
    rightsGainMethod?: string | number
    extraRightsGainMethod?: string | number
    extraRightsGainDuration?: string | number
    nextRightsGainDuration?: string | number
    rightsGainType?: string | number
    rightsGainDuration?: string | number
    gainMethodStep?: string | number
    generalRightsInfo?: string
    rightsExtJson?: string
    appInfo?: string
    contextInfo?: string
    installed?: string | number
    sniffTime?: string | number
    type_ids?: string
  } & RequestBaseConfig,
): Promise<Response>

export function activate_init_profile(
  params: { nickname: string } & RequestBaseConfig,
): Promise<Response>

export function album(
  params: { id: string | number } & RequestBaseConfig,
): Promise<Response>

export function album_detail(
  params: { id: string | number } & RequestBaseConfig,
): Promise<Response>

export function album_detail_dynamic(
  params: { id: string | number } & RequestBaseConfig,
): Promise<Response>

export const enum AlbumListArea {
  all = 'ALL',
  zh = 'ZH',
  ea = 'EA',
  kr = 'KR',
  jp = 'JP',
}

export const enum ListOrder {
  hot = 'hot',
  new = 'new',
}

export function album_list(
  params: { area?: AlbumListArea; type: string } & MultiPageConfig &
    RequestBaseConfig,
): Promise<Response>

export const enum AlbumListStyleArea {
  zh = 'Z_H',
  ea = 'E_A',
  kr = 'KR',
  jp = 'JP',
}

export function album_list_style(
  params: { area?: AlbumListStyleArea } & MultiPageConfig & RequestBaseConfig,
): Promise<Response>

export function album_new(
  params: { area?: AlbumListArea } & MultiPageConfig & RequestBaseConfig,
): Promise<Response>

export function album_newest(params: RequestBaseConfig): Promise<Response>

export const enum AlbumSongsaleboardType {
  daily = 'daily',
  week = 'week',
  year = 'year',
  total = 'total',
}

export const enum AlbumSongsaleboardAlbumType {
  album = 0,
  single = 1,
}

export function album_songsaleboard(
  params: {
    albumType?: AlbumSongsaleboardAlbumType // 0 为数字专辑,1 为数字单曲
    type?: AlbumSongsaleboardType
    year?: string | number // 年份，默认本年。 type 为 year 时有效
  } & RequestBaseConfig,
): Promise<Response>

export function album_sub(
  params: {
    id: string | number
    t: SubAction
  } & RequestBaseConfig,
): Promise<Response>

export function album_sublist(
  params: MultiPageConfig & RequestBaseConfig,
): Promise<Response>

export function api(
  params: {
    uri: string
    data?: string | Record<string, unknown>
    crypto?: string
  } & RequestBaseConfig,
): Promise<Response>

export function artist_album(
  params: { id: string | number } & MultiPageConfig & RequestBaseConfig,
): Promise<Response>

export function artist_desc(
  params: { id: string | number } & RequestBaseConfig,
): Promise<Response>

export const enum ArtistListArea {
  zh = 'Z_H',
  ea = 'E_A',
  kr = 'KR',
  jp = 'JP',
}

export const enum ArtistArea {
  all = '-1',
  zh = '7',
  ea = '96',
  ja = '8',
  kr = '16',
  other = '0',
}

export const enum ArtistType {
  male = '1',
  female = '2',
  band = '3',
}

export function artist_list(
  params: {
    area: ArtistArea
    initial?:
      | 'a'
      | 'b'
      | 'c'
      | 'd'
      | 'e'
      | 'f'
      | 'g'
      | 'h'
      | 'i'
      | 'j'
      | 'k'
      | 'l'
      | 'm'
      | 'n'
      | 'o'
      | 'p'
      | 'q'
      | 'r'
      | 's'
      | 't'
      | 'u'
      | 'v'
      | 'w'
      | 'x'
      | 'y'
      | 'z'
      | 'A'
      | 'B'
      | 'C'
      | 'D'
      | 'E'
      | 'F'
      | 'G'
      | 'H'
      | 'I'
      | 'J'
      | 'K'
      | 'L'
      | 'M'
      | 'N'
      | 'O'
      | 'P'
      | 'Q'
      | 'R'
      | 'S'
      | 'T'
      | 'U'
      | 'V'
      | 'W'
      | 'X'
      | 'Y'
      | 'Z'
    type?: ArtistType
  } & MultiPageConfig &
    RequestBaseConfig,
): Promise<Response>

export function artist_mv(
  params: { id: string | number } & MultiPageConfig & RequestBaseConfig,
): Promise<Response>

export const enum ArtistSongsOrder {
  hot = 'hot',
  time = 'time',
}

export function artist_songs(
  params: {
    id: string | number
    order?: ArtistSongsOrder
  } & MultiPageConfig &
    RequestBaseConfig,
): Promise<Response>

export function artist_sub(
  params: { id: string | number; t: SubAction } & RequestBaseConfig,
): Promise<Response>

export function artist_sublist(
  params: MultiPageConfig & RequestBaseConfig,
): Promise<Response>

export function artist_top_song(
  params: {
    id: string | number
  } & RequestBaseConfig,
): Promise<Response>

export function artists(
  params: { id: string | number } & RequestBaseConfig,
): Promise<Response>

export function audio_match(
  params: {
    duration: string | number
    audioFP: string | number
  } & RequestBaseConfig,
): Promise<Response>

export function avatar_upload(
  params: ImageUploadConfig & RequestBaseConfig,
): Promise<Response>

export const enum BannerType {
  pc = 0,
  android = 1,
  iphone = 2,
  ipad = 3,
}

export function banner(
  params: { type?: BannerType } & RequestBaseConfig,
): Promise<Response>

export function batch(
  params: { [index: string]: unknown } & RequestBaseConfig,
): Promise<Response>

export function captcha_safe_sent(
  params: { ctcode?: number | string } & RequestBaseConfig,
): Promise<Response>

export function captcha_sent(
  params: { phone: string; ctcode?: number | string } & RequestBaseConfig,
): Promise<Response>

export function captcha_sent_v1(
  params: {
    phone: number | string
    ctcode?: number | string
  } & RequestBaseConfig,
): Promise<Response>

export function captcha_verify(
  params: {
    ctcode?: number | string
    phone: number | string
    captcha: string
  } & RequestBaseConfig,
): Promise<Response>

export function cellphone_existence_check(
  params: {
    phone: number | string
    countrycode: number | string
  } & RequestBaseConfig,
): Promise<Response>

export function check_music(
  params: { id: string | number; br: string | number } & RequestBaseConfig,
): Promise<Response>

export const enum SearchType {
  single = 1,
  album = 10,
  artist = 100,
  playlist = 1000,
  user = 1002,
  mv = 1004,
  lyric = 1006,
  dj = 1009,
  video = 1014,
  complex = 1018,
}

export function cloudsearch(
  params: {
    keywords: string
    type?: SearchType
  } & MultiPageConfig &
    RequestBaseConfig,
): Promise<Response>

export const enum CommentType {
  song = 0,
  mv = 1,
  playlist = 2,
  album = 3,
  dj = 4,
  video = 5,
  event = 6,
}

export const enum CommentAction {
  add = 1,
  delete = 0,
  reply = 2,
}

export function comment(
  params: {
    id: string | number
    type: CommentType
    t: CommentAction.delete
    commentId: string | number
  } & RequestBaseConfig,
): Promise<Response>

export function comment(
  params: {
    type: CommentType.event
    t: CommentAction.delete
    threadId: string
    commentId: string | number
  } & RequestBaseConfig,
): Promise<Response>

export function comment(
  params: {
    id: string | number
    type: CommentType
    t: CommentAction.add
    content: string | number
  } & RequestBaseConfig,
): Promise<Response>

export function comment(
  params: {
    type: CommentType.event
    t: CommentAction.add
    threadId: string
    content: string | number
  } & RequestBaseConfig,
): Promise<Response>

export function comment(
  params: {
    id: string | number
    type: CommentType
    t: CommentAction.reply
    content: string | number
    commentId: string | number
  } & RequestBaseConfig,
): Promise<Response>

export function comment(
  params: {
    type: CommentType.event
    t: CommentAction.reply
    threadId: string
    content: string | number
    commentId: string | number
  } & RequestBaseConfig,
): Promise<Response>

export function comment_add(
  params: {
    id: string | number
    type: CommentType
    content: string
  } & RequestBaseConfig,
): Promise<Response>

export function comment_album(
  params: {
    id: string | number
    before?: string | number
  } & MultiPageConfig &
    RequestBaseConfig,
): Promise<Response>

export function comment_delete(
  params: {
    id: string | number
    type: CommentType
    cid: string | number
  } & RequestBaseConfig,
): Promise<Response>

export function comment_dj(
  params: {
    id: string | number
    before?: string | number
  } & MultiPageConfig &
    RequestBaseConfig,
): Promise<Response>

export function comment_event(
  params: {
    threadId: string
    before?: string | number
  } & MultiPageConfig &
    RequestBaseConfig,
): Promise<Response>

export function comment_floor(
  params: {
    id: string | number
    parentCommentId: string | number
    type: CommentType
    limit?: string | number
    time?: string | number
  } & RequestBaseConfig,
): Promise<Response>

export function comment_hot(
  params: {
    id: string | number
    type: CommentType
    before?: string | number
  } & MultiPageConfig &
    RequestBaseConfig,
): Promise<Response>

export function comment_hotwall_list(
  params: RequestBaseConfig,
): Promise<Response>

export function comment_like(
  params: {
    id: string | number
    type: CommentType
    t: SubAction
    cid: string | number
    threadId?: string
  } & RequestBaseConfig,
): Promise<Response>

export function comment_music(
  params: {
    id: string | number
    before?: string | number
  } & MultiPageConfig &
    RequestBaseConfig,
): Promise<Response>

export function comment_mv(
  params: {
    id: string | number
    before?: string | number
  } & MultiPageConfig &
    RequestBaseConfig,
): Promise<Response>

export function comment_playlist(
  params: {
    id: string | number

    before?: string | number
  } & MultiPageConfig &
    RequestBaseConfig,
): Promise<Response>

export function comment_reply(
  params: {
    id: string | number
    type: CommentType
    cid: string | number
    content: string
  } & RequestBaseConfig,
): Promise<Response>

export function comment_video(
  params: {
    id: string | number
    before?: string | number
  } & MultiPageConfig &
    RequestBaseConfig,
): Promise<Response>

export function countries_code_list(
  params: RequestBaseConfig,
): Promise<Response>

export const enum DailySigninType {
  android = 0,
  pc = 1,
}

export function daily_signin(
  params: { type?: DailySigninType } & RequestBaseConfig,
): Promise<Response>

export function decrypt(
  params: {
    crypto?: string
    data?: string
    hexString?: string
    isReq?: boolean | string
  } & RequestBaseConfig,
): Promise<Response>

export function device_kickoff(
  params: { deviceKey: string | number; captcha?: string } & RequestBaseConfig,
): Promise<Response>

export function device_list(params: RequestBaseConfig): Promise<Response>

export function deviceinfo_center_upload(
  params: { deviceName: string; name?: string } & RequestBaseConfig,
): Promise<Response>

export function digitalAlbum_ordering(
  params: {
    payment: string
    id: string | number
    quantity: string
  } & RequestBaseConfig,
): Promise<Response>

export function digitalAlbum_purchased(
  params: MultiPageConfig & RequestBaseConfig,
): Promise<Response>

export function dj_banner(params: RequestBaseConfig): Promise<Response>

export function dj_category_excludehot(
  params: RequestBaseConfig,
): Promise<Response>

export function dj_category_recommend(
  params: RequestBaseConfig,
): Promise<Response>

export function dj_catelist(params: RequestBaseConfig): Promise<Response>

export function dj_detail(
  params: { rid: string | number } & RequestBaseConfig,
): Promise<Response>

export function dj_hot(
  params: MultiPageConfig & RequestBaseConfig,
): Promise<Response>

export function dj_paygift(
  params: MultiPageConfig & RequestBaseConfig,
): Promise<Response>

export function dj_personalize_recommend(
  params: { limit?: string | number } & RequestBaseConfig,
): Promise<Response>

export function dj_program(
  params: {
    rid: string | number
    asc: 'true' | 1 | 'false' | 0
  } & MultiPageConfig &
    RequestBaseConfig,
): Promise<Response>

export function dj_program_detail(
  params: { id: string | number } & RequestBaseConfig,
): Promise<Response>

export function dj_program_toplist(
  params: MultiPageConfig & RequestBaseConfig,
): Promise<Response>

export function dj_program_toplist_hours(
  params: { limit?: string | number } & RequestBaseConfig,
): Promise<Response>

export function dj_radio_hot(
  params: {
    cateId: string | number
  } & MultiPageConfig &
    RequestBaseConfig,
): Promise<Response>

export function dj_recommend(params: RequestBaseConfig): Promise<Response>

/*
  有声书 10001
  知识技能 453050
  商业财经 453051
  人文历史 11
  外语世界 13
  亲子宝贝 14
  创作|翻唱 2001
  音乐故事 2
  3D|电子 10002
  相声曲艺 8
  情感调频 3
  美文读物 6
  脱口秀 5
  广播剧 7
  二次元 3001
  明星做主播 1
  娱乐|影视 4
  科技科学 453052
  校园|教育 4001
  旅途|城市 12
*/

export function dj_recommend_type(
  params: { type: number } & RequestBaseConfig,
): Promise<Response>

export function dj_sub(
  params: { t: SubAction; rid: string | number } & RequestBaseConfig,
): Promise<Response>

export function dj_sublist(
  params: MultiPageConfig & RequestBaseConfig,
): Promise<Response>

export function dj_today_perfered(
  params: { page?: string | number } & RequestBaseConfig,
): Promise<Response>

export function dj_toplist(
  params: { type?: ListOrder } & MultiPageConfig & RequestBaseConfig,
): Promise<Response>

export function dj_toplist_hours(
  params: { limit?: string | number } & RequestBaseConfig,
): Promise<Response>

export function dj_toplist_newcomer(
  params: MultiPageConfig & RequestBaseConfig,
): Promise<Response>

export function dj_toplist_pay(
  params: { limit?: string | number } & RequestBaseConfig,
): Promise<Response>

export function dj_toplist_popular(
  params: { limit?: string | number } & RequestBaseConfig,
): Promise<Response>

export function eapi_decrypt(
  params: { hexString: string; isReq?: boolean | string } & RequestBaseConfig,
): Promise<Response>

export function event(
  params: { pagesize?: number; lasttime?: number } & RequestBaseConfig,
): Promise<Response>

export function event_del(
  params: { evId: string | number } & RequestBaseConfig,
): Promise<Response>

export const enum EventPrivacy {
  everyone = 0,
  following = 1,
  onlyMe = 2,
  mutualFollowing = 6,
}

export function event_privacy(
  params: {
    evId: string | number
    privacy: EventPrivacy
  } & RequestBaseConfig,
): Promise<Response>

export function event_forward(
  params: {
    forwords: string
    evId: string | number
    uid: string | number
  } & RequestBaseConfig,
): Promise<Response>

export function fm_trash(
  params: { id: string | number; time?: string | number } & RequestBaseConfig,
): Promise<Response>

export function follow(
  params: { t: SubAction; id: string | number } & RequestBaseConfig,
): Promise<Response>

export function history_recommend_songs(
  params: RequestBaseConfig,
): Promise<Response>

export function history_recommend_songs_detail(
  params: { date?: string } & RequestBaseConfig,
): Promise<Response>

export function homepage_block_page(
  params: {
    refresh?: 'true' | 'false' | boolean
    cursor?: string
  } & RequestBaseConfig,
): Promise<Response>

export function homepage_dragon_ball(
  params: RequestBaseConfig,
): Promise<Response>

export function hot_topic(
  params: MultiPageConfig & RequestBaseConfig,
): Promise<Response>

export function inner_version(params: RequestBaseConfig): Promise<Response>

export function like(
  params: {
    like?: 'true' | 'false' | boolean
    id: string | number
    alg?: string
    time?: string | number
  } & RequestBaseConfig,
): Promise<Response>

export function likelist(
  params: { uid: string | number } & RequestBaseConfig,
): Promise<Response>

export function listentogether_status(
  params: RequestBaseConfig,
): Promise<Response>

export function login(
  params: { email: string; password: string } & RequestBaseConfig,
): Promise<Response>

export function login(
  params: { email: string; md5_password: string } & RequestBaseConfig,
): Promise<Response>

export function login_cellphone(
  params: {
    phone: number | string
    countrycode?: number | string
    password: string
  } & RequestBaseConfig,
): Promise<Response>

export function login_cellphone(
  params: {
    phone: number | string
    countrycode?: number | string
    md5_password: string
  } & RequestBaseConfig,
): Promise<Response>

export function login_cellphone(
  params: {
    phone: number | string
    countrycode?: number | string
    captcha: number | string
  } & RequestBaseConfig,
): Promise<Response>

export function login_refresh(params: RequestBaseConfig): Promise<Response>

export function login_status(params: RequestBaseConfig): Promise<Response>

export function logout(params: RequestBaseConfig): Promise<Response>

export function lyric(
  params: { id: string | number } & RequestBaseConfig,
): Promise<Response>

export function lyric_new(
  params: { id: string | number } & RequestBaseConfig,
): Promise<Response>

export function middle_play_do_lottery(
  params: {
    activityId?: string | number
    drawCount?: string | number
  } & RequestBaseConfig,
): Promise<Response>

export function middle_play_lottery_remain_chance(
  params: { activityId?: string | number } & RequestBaseConfig,
): Promise<Response>

export function msg_comments(
  params: {
    uid: string | number
    before?: string | number
    limit?: string | number
  } & RequestBaseConfig,
): Promise<Response>

export function msg_forwards(
  params: MultiPageConfig & RequestBaseConfig,
): Promise<Response>

export function msg_notices(
  params: {
    limit?: string | number
    lasttime?: string | number
  } & RequestBaseConfig,
): Promise<Response>

export function msg_private(
  params: MultiPageConfig & RequestBaseConfig,
): Promise<Response>

export function msg_private_history(
  params: {
    before?: string | number
    limit?: string | number
    uid: string | number
  } & RequestBaseConfig,
): Promise<Response>

export const enum MvArea {
  all = '全部',
  zh = '内地',
  hk = '港台',
  ea = '欧美',
  kr = '韩国',
  jp = '日本',
}

export const enum MvType {
  all = '全部',
  offical = '官方版',
  raw = '原生',
  live = '现场版',
  netease = '网易出品',
}

export const enum MvOrder {
  trend = '上升最快',
  hot = '最热',
  new = '最新',
}

export function mv_all(
  params: {
    area?: MvArea
    type?: MvType
    order?: MvOrder
  } & MultiPageConfig &
    RequestBaseConfig,
): Promise<Response>

export function mv_detail(
  params: { mvid?: string | number } & RequestBaseConfig,
): Promise<Response>

export function mv_detail_info(
  params: { mvid: string | number } & RequestBaseConfig,
): Promise<Response>

export function mv_exclusive_rcmd(
  params: MultiPageConfig & RequestBaseConfig,
): Promise<Response>

export function mv_first(
  params: { area?: MvArea; limit?: string | number } & RequestBaseConfig,
): Promise<Response>

export function mv_sub(
  params: { t: SubAction; mvid: string | number } & RequestBaseConfig,
): Promise<Response>

export function mv_sublist(
  params: MultiPageConfig & RequestBaseConfig,
): Promise<Response>

export function mv_url(
  params: { id?: string | number; r?: string | number } & RequestBaseConfig,
): Promise<Response>

export function personal_fm(params: RequestBaseConfig): Promise<Response>

export function personalized(
  params: { limit?: string | number } & RequestBaseConfig,
): Promise<Response>

export function personalized_djprogram(
  params: RequestBaseConfig,
): Promise<Response>

export function personalized_mv(params: RequestBaseConfig): Promise<Response>

export function personalized_newsong(
  params: {
    area?: string | number
    limit?: string | number
  } & RequestBaseConfig,
): Promise<Response>

export function personalized_privatecontent(
  params: RequestBaseConfig,
): Promise<Response>

export function personalized_privatecontent_list(
  params: MultiPageConfig & RequestBaseConfig,
): Promise<Response>

export function playlist_catlist(params: RequestBaseConfig): Promise<Response>

export function playlist_cover_update(
  params: { id: string } & ImageUploadConfig & RequestBaseConfig,
): Promise<Response>

export function playlist_create(
  params: {
    name: string
    privacy: 0 | 10
    type?: PlaylistType
  } & RequestBaseConfig,
): Promise<Response>

export function playlist_delete(
  params: { id: string | number } & RequestBaseConfig,
): Promise<Response>

export function playlist_desc_update(
  params: { id: string | number; desc: string } & RequestBaseConfig,
): Promise<Response>

export function playlist_detail(
  params: { id: string | number; s?: string | number } & RequestBaseConfig,
): Promise<Response>

export function playlist_highquality_tags(
  params: RequestBaseConfig,
): Promise<Response>

export function playlist_hot(params: RequestBaseConfig): Promise<Response>

export function playlist_name_update(
  params: { id: string | number; name: string } & RequestBaseConfig,
): Promise<Response>

export function playlist_order_update(
  params: { ids: string } & RequestBaseConfig,
): Promise<Response>

export function playlist_subscribe(
  params: { t: SubAction; id: string | number } & RequestBaseConfig,
): Promise<Response>

export function playlist_subscribers(
  params: { id?: string | number } & MultiPageConfig & RequestBaseConfig,
): Promise<Response>

export function playlist_tags_update(
  params: { id: string | number; tags: string } & RequestBaseConfig,
): Promise<Response>

export function playlist_tracks(
  params: {
    op: 'add' | 'del'
    pid: string | number
    tracks: string
  } & RequestBaseConfig,
): Promise<Response>

export function playlist_update(
  params: {
    id: string | number
    name: string
    desc?: string
    tags?: string
  } & RequestBaseConfig,
): Promise<Response>

export function playmode_intelligence_list(
  params: {
    id: string | number
    pid: string | number
    sid?: string | number
    count?: string | number
  } & RequestBaseConfig,
): Promise<Response>

export function program_recommend(
  params: { type: string } & MultiPageConfig & RequestBaseConfig,
): Promise<Response>

export function rebind(
  params: {
    captcha: string
    phone: string
    oldcaptcha: string
    ctcode?: number | string
  } & RequestBaseConfig,
): Promise<Response>

export function recommend_resource(params: RequestBaseConfig): Promise<Response>

export function recommend_songs(params: RequestBaseConfig): Promise<Response>

export function register_cellphone(
  params: {
    captcha: string
    phone: string
    password: string
    nickname: string
  } & RequestBaseConfig,
): Promise<Response>

export function register_checktoken_v2(
  params: { refresh?: boolean | string } & RequestBaseConfig,
): Promise<Response>

export function register_checktoken_v3(
  params: { refresh?: boolean | string } & RequestBaseConfig,
): Promise<Response>

export function register_neapikey(
  params: { version?: string | number; behavior?: string } & RequestBaseConfig,
): Promise<Response>

export function register_xeapikey(
  params: { deviceId?: string; currentKeyVersion?: string } & RequestBaseConfig,
): Promise<Response>

export function related_allvideo(
  params: { id: string | number } & RequestBaseConfig,
): Promise<Response>

export function related_playlist(
  params: { id: string | number } & RequestBaseConfig,
): Promise<Response>

export function relay_play_state_submit(
  params: {
    id: string | number
    sessionId?: string
    progress?: string | number
    playMode?: string
    type?: string
  } & RequestBaseConfig,
): Promise<Response>

export function rep_ugc_activity_collect(
  params: { activityId?: string | number } & RequestBaseConfig,
): Promise<Response>

export function rep_ugc_activity_get(
  params: RequestBaseConfig,
): Promise<Response>

export function rep_ugc_exam_info_get(
  params: { examType: string | number } & RequestBaseConfig,
): Promise<Response>

export function rep_ugc_exam_question_single_get(
  params: {
    examType: string | number
    taskId: string | number
  } & RequestBaseConfig,
): Promise<Response>

export function rep_ugc_exam_result_get(
  params: {
    examType: string | number
    taskId: string | number
  } & RequestBaseConfig,
): Promise<Response>

export function rep_ugc_exam_start(
  params: { examType: string | number } & RequestBaseConfig,
): Promise<Response>

export function rep_ugc_exam_submit(
  params: {
    examType: string | number
    taskId: string | number
    questionId: string | number
    answer: string
  } & RequestBaseConfig,
): Promise<Response>

declare const rep_ugc_user_collect_vip: (
  params: { activityId?: string | number } & RequestBaseConfig,
) => Promise<Response>

export { rep_ugc_user_collect_vip as 'rep_ugc_user_collect-vip' }

export function rep_ugc_user_get(params: RequestBaseConfig): Promise<Response>

export function rep_ugc_user_sign(params: RequestBaseConfig): Promise<Response>

export function rep_ugc_user_vip(params: RequestBaseConfig): Promise<Response>

export const enum ResourceType {
  mv = 1,
  dj = 4,
  video = 5,
  event = 6,
}
type PlaylistType = 'NROMAL' | 'VIDEO'

export function resource_like(
  params: {
    t: SubAction
    type: ResourceType
    id?: string | number
    threadId?: string
  } & RequestBaseConfig,
): Promise<Response>

export function scrobble(
  params: {
    id: string | number
    sourceid: string | number
    time: string | number
  } & RequestBaseConfig,
): Promise<Response>

export function scrobble_v1(
  params: {
    id: string | number
    time: string | number
    total?: string | number
    sourceid?: string | number
    sourceId?: string | number
    source?: string
    name?: string
    artist?: string
    bitrate?: string | number
    level?: string
    vip?: boolean | string
  } & RequestBaseConfig,
): Promise<Response>

export function search(
  params: {
    keywords: string
    type?: SearchType
  } & MultiPageConfig &
    RequestBaseConfig,
): Promise<Response>

export function search_default(params: RequestBaseConfig): Promise<Response>

export function search_hot(params: RequestBaseConfig): Promise<Response>

export function search_hot_detail(params: RequestBaseConfig): Promise<Response>

export function search_multimatch(
  params: { type?: number; keywords: string } & RequestBaseConfig,
): Promise<Response>

export const enum SearchSuggestType {
  mobile = 'mobile',
  web = 'web',
}

export function search_suggest(
  params: { keywords: string; type?: SearchSuggestType } & RequestBaseConfig,
): Promise<Response>

export function send_playlist(
  params: {
    playlist: string | number
    msg: string
    user_ids: string
  } & RequestBaseConfig,
): Promise<Response>

export function send_text(
  params: { msg: string; user_ids: string } & RequestBaseConfig,
): Promise<Response>

export function setting(params: RequestBaseConfig): Promise<Response>

export const enum ShareResourceType {
  song = 'song',
  playlist = 'playlist',
  mv = 'mv',
  djprogram = 'djprogram',
  djradio = 'djradio',
}

export function share_resource(
  params: {
    type?: ShareResourceType
    msg?: string
    id?: string | number
  } & RequestBaseConfig,
): Promise<Response>

export function simi_artist(
  params: { id: string | number } & RequestBaseConfig,
): Promise<Response>

export function simi_mv(
  params: { mvid: string | number } & RequestBaseConfig,
): Promise<Response>

export function simi_playlist(
  params: { id: string | number } & MultiPageConfig & RequestBaseConfig,
): Promise<Response>

export function simi_song(
  params: { id: string | number } & MultiPageConfig & RequestBaseConfig,
): Promise<Response>

export function simi_user(
  params: { id: string | number } & MultiPageConfig & RequestBaseConfig,
): Promise<Response>

export function song_detail(
  params: { ids: string } & RequestBaseConfig,
): Promise<
  Response<{
    songs: SongDetail[]
    privileges: unknown[]
    code: number
  }>
>

type SongDetail = {
  name: string
  id: number
  pst: number
  t: number
  ar: SongDetailArtist[]
  alia: string[]
  pop: number
  st: number
  rt: string | null
  fee: SongDetailFee
  v: number
  crbt: string | null
  cf: string
  al: SongDetailAlbum
  dt: number
  h: SongDetailQuality | null
  m: SongDetailQuality | null
  l: SongDetailQuality | null
  sq: SongDetailQuality | null
  hr: SongDetailQuality | null
  a: unknown | null
  cd: string
  no: number
  rtUrl: unknown | null
  ftype: number
  rtUrls: unknown[]
  djId: number
  copyright: SongDetailCopyright
  s_id: number
  mark: number
  originCoverType: SongDetailOriginCoverType
  originSongSimpleData: unknown | null
  tagPicList: unknown | null
  resourceState: boolean
  version: number
  songJumpInfo: unknown | null
  entertainmentTags: unknown | null
  awardTags: unknown | null
  single: number
  noCopyrightRcmd: unknown | null
  mv: number
  rtype: number
  rurl: unknown | null
  mst: number
  cp: number
  publishTime: number
}

type SongDetailArtist = {
  id: number
  name: string
  tns: unknown[]
  alias: unknown[]
}

type SongDetailFee = 0 | 1 | 4 | 8

type SongDetailAlbum = {
  id: number
  name: string
  picUrl: string
  tns: unknown[]
  pic: number
}

type SongDetailQuality = {
  br: number
  fid: number
  size: number
  vd: number
  sr: number
}

type SongDetailCopyright = 0 | 1 | 2

type SongDetailOriginCoverType = 0 | 1 | 2

export function song_order_update(
  params: { pid: string | number; ids: string } & RequestBaseConfig,
): Promise<Response>

export function song_url(
  params: { id: string | number; br?: string | number } & RequestBaseConfig,
): Promise<Response>

export const enum SoundQualityType {
  standard = 'standard',
  exhigh = 'exhigh',
  lossless = 'lossless',
  hires = 'hires',
  jyeffect = 'jyeffect',
  jymaster = 'jymaster',
  sky = 'sky',
  vivid = 'vivid',
}

export function song_url_v1(
  params: { id: string | number; level: SoundQualityType } & RequestBaseConfig,
): Promise<Response>

export function song_copyright_rcmd(
  params: {
    songid?: string | number
    id?: string | number
  } & RequestBaseConfig,
): Promise<Response>

export function top_album(
  params: {
    area?: AlbumListArea
    type?: ListOrder
    year?: string
    mouth?: string
  } & MultiPageConfig &
    RequestBaseConfig,
): Promise<Response>

export function top_artists(
  params: MultiPageConfig & RequestBaseConfig,
): Promise<Response>

export function top_list(
  params: { id: string | number } & RequestBaseConfig,
): Promise<Response>

export function top_mv(
  params: { area?: MvArea } & MultiPageConfig & RequestBaseConfig,
): Promise<Response>

export function top_playlist(
  params: { cat?: string; order?: ListOrder } & MultiPageConfig &
    RequestBaseConfig,
): Promise<Response>

export function top_playlist_highquality(
  params: {
    cat?: string
    before?: string | number
    limit?: string | number
  } & RequestBaseConfig,
): Promise<Response>

export const enum TopSongType {
  all = 0,
  zh = 7,
  ea = 96,
  kr = 16,
  ja = 8,
}

export function top_song(
  params: { type: TopSongType } & RequestBaseConfig,
): Promise<Response>

export function toplist(params: RequestBaseConfig): Promise<Response>

export const enum ToplistArtistType {
  zh = 1,
  ea = 2,
  kr = 3,
  ja = 4,
}

export function toplist_artist(
  params: { type?: ToplistArtistType } & RequestBaseConfig,
): Promise<Response>

export function toplist_detail(params: RequestBaseConfig): Promise<Response>

export function user_audio(
  params: { uid: string | number } & RequestBaseConfig,
): Promise<Response>

export function user_cloud(
  params: MultiPageConfig & RequestBaseConfig,
): Promise<Response>

export function user_cloud_del(
  params: { id: string | number } & RequestBaseConfig,
): Promise<Response>

export function user_cloud_detail(
  params: { id: string | number } & RequestBaseConfig,
): Promise<Response>

export function user_detail(
  params: { uid: string | number } & RequestBaseConfig,
): Promise<Response>

export function user_dj(
  params: { uid: string | number } & MultiPageConfig & RequestBaseConfig,
): Promise<Response>

export function user_event(
  params: {
    lasttime?: string | number
    limit?: string | number
    uid: string | number
  } & RequestBaseConfig,
): Promise<Response>

export interface UserEventAllResponse {
  code: number
  events: Record<string, unknown>[]
  /** Upstream account statistic; it can include events no longer returned. */
  size: number | null
  /** Number of unique events in `events`. */
  retrievedCount: number
  /** Positive difference between `size` and `retrievedCount`. */
  unavailableCount: number | null
  sizeMismatch: boolean | null
  pageCount: number
  more: false
  lasttime: string | number | null
}

export function user_event_all(
  params: RequestBaseConfig,
): Promise<Response<UserEventAllResponse>>

export function user_followeds(
  params: {
    uid: string | number
    lasttime?: string | number
    limit?: string | number
  } & RequestBaseConfig,
): Promise<Response>

export function user_follows(
  params: { uid: string | number } & MultiPageConfig & RequestBaseConfig,
): Promise<Response>

export function user_level(params: RequestBaseConfig): Promise<Response>

export function user_playlist(
  params: { uid: string | number } & MultiPageConfig & RequestBaseConfig,
): Promise<Response>

export const enum UserRecordType {
  all = 0,
  weekly = 1,
}

export function user_record(
  params: { uid: string | number; type?: UserRecordType } & RequestBaseConfig,
): Promise<Response>

export function user_subcount(params: RequestBaseConfig): Promise<Response>

export function user_update(
  params: {
    birthday: string
    city: string
    gender: string
    nickname: string
    province: string
    signature: string
  } & RequestBaseConfig,
): Promise<Response>

export function video_category_list(
  params: MultiPageConfig & RequestBaseConfig,
): Promise<Response>

export function video_detail(
  params: { id: string } & RequestBaseConfig,
): Promise<Response>

export function video_detail_info(
  params: { vid: string } & RequestBaseConfig,
): Promise<Response>

export function video_group(
  params: { id: string; offset?: string | number } & RequestBaseConfig,
): Promise<Response>

export function video_group_list(params: RequestBaseConfig): Promise<Response>

export function video_sub(
  params: { t?: SubAction; id: string } & RequestBaseConfig,
): Promise<Response>

export function video_timeline_all(
  params: { offset?: string | number } & RequestBaseConfig,
): Promise<Response>

export function video_timeline_recommend(
  params: { offset?: string | number } & RequestBaseConfig,
): Promise<Response>

export function video_url(
  params: { id: string | number; res?: number } & RequestBaseConfig,
): Promise<Response>

export function weblog(
  params: { data?: { [index: string]: unknown } } & RequestBaseConfig,
): Promise<Response>

export function playlist_mylike(
  params: {
    time?: number | string
    limit: number | string
  } & RequestBaseConfig,
): Promise<Response>

export function playlist_track_add(
  params: { pid?: number | string; ids: number | string } & RequestBaseConfig,
): Promise<Response>

export function playlist_track_delete(
  params: { pid?: number | string; ids: number | string } & RequestBaseConfig,
): Promise<Response>

export function comment_new(
  params: {
    type?: number | string
    id: number | string
    pageNo?: number | string
    pageSize?: number | string
    sortType?: number | string
  } & RequestBaseConfig,
): Promise<Response>

export function calendar(
  params: {
    startTime?: number | string
    endTime: number | string
  } & RequestBaseConfig,
): Promise<Response>

export function playlist_video_recent(
  params: RequestBaseConfig,
): Promise<Response>

export function user_binding(
  params: { uid?: number | string } & RequestBaseConfig,
): Promise<Response>

export function user_replacephone(
  params: {
    phone: number | string
    captcha: number | string
    oldcaptcha: number | string
    countrycode?: number | string
  } & RequestBaseConfig,
): Promise<Response>

export function user_safe(params: RequestBaseConfig): Promise<Response>

export function dj_subscriber(
  params: {
    id: number | string
    limit?: number | string
    time?: number | string
  } & RequestBaseConfig,
): Promise<Response>

export function user_account(params: RequestBaseConfig): Promise<Response>

export function yunbei(params: RequestBaseConfig): Promise<Response>

export function yunbei_info(params: RequestBaseConfig): Promise<Response>

export function yunbei_sign(params: RequestBaseConfig): Promise<Response>

export function yunbei_receipt(
  params: MultiPageConfig & RequestBaseConfig,
): Promise<Response>

export function yunbei_expense(
  params: MultiPageConfig & RequestBaseConfig,
): Promise<Response>

export function yunbei_tasks(params: RequestBaseConfig): Promise<Response>

export function yunbei_today(params: RequestBaseConfig): Promise<Response>

export function yunbei_tasks_todo(params: RequestBaseConfig): Promise<Response>

export function yunbei_task_finish(
  params: {
    userTaskId: number | string
    depositCode?: number | string
  } & RequestBaseConfig,
): Promise<Response>

export function yunbei_ad_task_list(
  params: RequestBaseConfig,
): Promise<Response>

export function yunbei_ad_task_recommend_song(
  params: {
    offset?: number | string
    limit?: number | string
  } & RequestBaseConfig,
): Promise<Response>

export function yunbei_ad_task_finish(
  params: {
    yunbeiAmount?: number | string
  } & RequestBaseConfig,
): Promise<Response>

export function msg_recentcontact(params: RequestBaseConfig): Promise<Response>

export function hug_comment(
  params: {
    uid: number | string
    cid: number | string
    sid: number | string
  } & RequestBaseConfig,
): Promise<Response>

export function comment_hug_list(
  params: {
    page: number | string
    cursor: number | string
    idCursor: number | string
    pageSize?: number | string
  } & RequestBaseConfig,
): Promise<Response>

export function topic_sublist(
  params: MultiPageConfig & RequestBaseConfig,
): Promise<Response>

export function topic_sublist(
  params: MultiPageConfig & RequestBaseConfig,
): Promise<Response>

export function artist_new_mv(
  params: {
    limit?: number | string
    startTimestamp?: number | string
  } & RequestBaseConfig,
): Promise<Response>

export function artist_new_song(
  params: {
    limit?: number | string
    startTimestamp?: number | string
  } & RequestBaseConfig,
): Promise<Response>

export function artist_new_song_playall(
  params: RequestBaseConfig,
): Promise<Response>

export function artist_new_song_mv_list_v2(
  params: {
    startTimestamp?: number | string
    before?: number | string
    sourceType?: number | string
    limit?: number | string
    firstRequest?: boolean | string
  } & RequestBaseConfig,
): Promise<Response>

export function artist_detail(
  params: {
    id: number | string
  } & RequestBaseConfig,
): Promise<Response>

export function cloud(
  params: {
    songFile: {
      name: string
      data: Buffer
    }
  } & RequestBaseConfig,
): Promise<Response>

export function topic_detail(
  params: {
    actid?: number | string
  } & RequestBaseConfig,
): Promise<Response>

export function topic_detail_event_hot(
  params: {
    actid?: number | string
  } & RequestBaseConfig,
): Promise<Response>

export function login_qr_key(params: RequestBaseConfig): Promise<Response>

export function login_qr_create(
  params: {
    key?: number | string
    qrimg?: boolean | string
  } & RequestBaseConfig,
): Promise<Response>

export function login_qr_check(
  params: {
    key?: number | string
  } & RequestBaseConfig,
): Promise<Response>

export function playlist_detail_dynamic(
  params: { id: string | number } & RequestBaseConfig,
): Promise<Response>

export function user_bindingcellphone(
  params: {
    phone: number | string
    captcha: number | string
    countrycode?: number | string
    password?: string
  } & RequestBaseConfig,
): Promise<Response>

export function listen_together_status(
  params: RequestBaseConfig,
): Promise<Response>

export function user_comment_history(
  params: {
    limit?: number | string
    uid: number | string
    time?: number | string
  } & RequestBaseConfig,
): Promise<Response>

export function cloud_match(
  params: {
    uid: number | string
    sid: number | string
    asid: number | string
  } & RequestBaseConfig,
): Promise<Response>

export function yunbei_rcmd_song(
  params: {
    id: number | string
    reason?: number | string
  } & RequestBaseConfig,
): Promise<Response>

export function yunbei_rcmd_song_history(
  params: {
    size?: number | string
    cursor?: number | string
  } & RequestBaseConfig,
): Promise<Response>

export function song_purchased(
  params: MultiPageConfig & RequestBaseConfig,
): Promise<Response>

export function mlog_url(
  params: {
    id?: number | string
    res?: number | string
  } & RequestBaseConfig,
): Promise<Response>

export function mlog_to_video(
  params: {
    id?: number | string
  } & RequestBaseConfig,
): Promise<Response>

export function vip_growthpoint(params: RequestBaseConfig): Promise<Response>

export function vip_growthpoint_details(
  params: MultiPageConfig & RequestBaseConfig,
): Promise<Response>

export function vip_tasks(params: RequestBaseConfig): Promise<Response>

export function vip_growthpoint_get(
  params: {
    ids?: number | string
  } & RequestBaseConfig,
): Promise<Response>

export function vip_growthpoint_getall(
  params: RequestBaseConfig,
): Promise<Response>

export function artist_fans(
  params: { id: number | string } & MultiPageConfig & RequestBaseConfig,
): Promise<Response>

export function digitalAlbum_detail(
  params: {
    id: number | string
  } & RequestBaseConfig,
): Promise<Response>

export function digitalAlbum_sales(
  params: {
    ids: number | string
  } & RequestBaseConfig,
): Promise<Response>

export function musician_data_overview(
  params: RequestBaseConfig,
): Promise<Response>

export function musician_play_trend(
  params: {
    startTime: number | string
    endTime: number | string
  } & RequestBaseConfig,
): Promise<Response>

export function musician_tasks(params: RequestBaseConfig): Promise<Response>

export function musician_cloudbean(params: RequestBaseConfig): Promise<Response>

export function musician_cloudbean_obtain(
  params: {
    id: number | string
    period: number | string
  } & RequestBaseConfig,
): Promise<Response>

export function vip_info(
  params: {
    uid?: number | string
  } & RequestBaseConfig,
): Promise<Response>

export function vip_info_v2(
  params: {
    uid?: number | string
  } & RequestBaseConfig,
): Promise<Response>

export function musician_sign(params: RequestBaseConfig): Promise<Response>

export function song_download_url(
  params: {
    id: number | string
    br?: number | string
  } & RequestBaseConfig,
): Promise<Response>

export function playlist_track_all(
  params: {
    id: number | string
    s?: number | string
  } & MultiPageConfig &
    RequestBaseConfig,
): Promise<Response>

export function artist_video(
  params: {
    id: number | string
    size?: number | string
    cursor?: number | string
    order?: number | string
  } & RequestBaseConfig,
): Promise<Response>

export function sign_happy_info(params: RequestBaseConfig): Promise<Response>

export function record_recent_song(
  params: {
    limit?: number | string
  } & RequestBaseConfig,
): Promise<Response>

export function record_recent_video(
  params: {
    limit?: number | string
  } & RequestBaseConfig,
): Promise<Response>

export function record_recent_voice(
  params: {
    limit?: number | string
  } & RequestBaseConfig,
): Promise<Response>

export function record_recent_playlist(
  params: {
    limit?: number | string
  } & RequestBaseConfig,
): Promise<Response>

export function record_recent_album(
  params: {
    limit?: number | string
  } & RequestBaseConfig,
): Promise<Response>

export function record_recent_dj(
  params: {
    limit?: number | string
  } & RequestBaseConfig,
): Promise<Response>

export function signin_progress(
  params: {
    moduleId?: string
  } & RequestBaseConfig,
): Promise<Response>

export function nickname_check(
  params: {
    nickname: string
  } & RequestBaseConfig,
): Promise<Response>

export function musician_tasks_new(params: RequestBaseConfig): Promise<Response>

export function musician_vip_tasks(params: RequestBaseConfig): Promise<Response>

export function playlist_update_playcount(
  params: {
    id?: number | string
  } & RequestBaseConfig,
): Promise<Response>

export function vip_timemachine(
  params: {
    startTime?: number | string
    endTime?: number | string
    limit?: number | string
  } & RequestBaseConfig,
): Promise<Response>

export function song_wiki_summary(
  params: {
    id: number | string
  } & RequestBaseConfig,
): Promise<Response>

export function sheet_list(
  params: {
    id: number | string
    abTest?: 'a' | 'b'
  } & RequestBaseConfig,
): Promise<Response>

export function sheet_preview(
  params: {
    id: number | string
  } & RequestBaseConfig,
): Promise<Response>

export function style_list(params: RequestBaseConfig): Promise<Response>

export function style_preference(params: RequestBaseConfig): Promise<Response>

export function style_detail(
  params: {
    tagId: number | string
  } & RequestBaseConfig,
): Promise<Response>

export function style_song(
  params: {
    tagId: number | string
    size?: number | string
    cursor?: number | string
    sort?: number | string
  } & RequestBaseConfig,
): Promise<Response>

export function style_album(
  params: {
    tagId: number | string
    size?: number | string
    cursor?: number | string
    sort?: number | string
  } & RequestBaseConfig,
): Promise<Response>

export function style_playlist(
  params: {
    tagId: number | string
    size?: number | string
    cursor?: number | string
  } & RequestBaseConfig,
): Promise<Response>

export function style_artist(
  params: {
    tagId: number | string
    size?: number | string
    cursor?: number | string
  } & RequestBaseConfig,
): Promise<Response>

export function pl_count(params: RequestBaseConfig): Promise<Response>

export function get_userids(
  params: {
    nicknames: string
  } & RequestBaseConfig,
): Promise<Response>

export function voicelist_list_search(
  params: {
    limit?: string | number
    offset?: string | number
    name?: string
    displayStatus?: string
    type?: string
    voiceFeeType?: string | number
    radioId?: string
  } & RequestBaseConfig,
): Promise<Response>

export function voice_delete(
  params: {
    ids: number | string
  } & RequestBaseConfig,
): Promise<Response>

export function djRadio_top(
  params: {
    djRadioId?: number | string
    sortIndex?: number | string
    dataGapDays?: number | string
    dataType?: number | string
  } & RequestBaseConfig,
): Promise<Response>

export function voice_lyric(
  params: {
    id: number | string
  } & RequestBaseConfig,
): Promise<Response>

export function aidj_content_rcmd(
  params: {
    latitude?: string | number
    longitude?: string | number
  } & RequestBaseConfig,
): Promise<Response>

export function album_privilege(
  params: {
    id: string | number
  } & RequestBaseConfig,
): Promise<Response>

export function artist_detail_dynamic(
  params: {
    id: string | number
  } & RequestBaseConfig,
): Promise<Response>

export function artist_follow_count(
  params: {
    id: string | number
  } & RequestBaseConfig,
): Promise<Response>

export function broadcast_category_region_get(
  params: RequestBaseConfig,
): Promise<Response>

export function broadcast_channel_collect_list(
  params: MultiPageConfig & RequestBaseConfig,
): Promise<Response>

export function broadcast_channel_currentinfo(
  params: {
    id: string | number
  } & RequestBaseConfig,
): Promise<Response>

export function broadcast_channel_list(
  params: {
    categoryId?: string | number
    regionId?: string | number
    lastId?: string | number
    score?: string | number
  } & MultiPageConfig &
    RequestBaseConfig,
): Promise<Response>

export function broadcast_sub(
  params: {
    t: SubAction
    id: string | number
  } & RequestBaseConfig,
): Promise<Response>

export function chart_detail(
  params: {
    chartCode: string | number
    targetId: string | number
    targetType: string | number
  } & RequestBaseConfig,
): Promise<Response>

export function chart_song_detail(
  params: {
    chartCode: string | number
    targetId: string | number
    targetType: string | number
  } & RequestBaseConfig,
): Promise<Response>

export function cloud_import(
  params: {
    md5: string
    id?: string | number
    bitrate?: string | number
    fileSize?: string | number
    artist?: string
    album?: string
    song?: string
  } & RequestBaseConfig,
): Promise<Response>

export function cloud_lyric_get(
  params: {
    uid: string | number
    sid: string | number
  } & RequestBaseConfig,
): Promise<Response>

export function cloud_upload_complete(
  params: {
    songId: string | number
    resourceId: string | number
    md5: string
    filename: string
    song?: string
    artist?: string
    album?: string
    bitrate?: string | number
  } & RequestBaseConfig,
): Promise<Response>

export function cloud_upload_token(
  params: {
    md5: string
    fileSize: string | number
    filename: string
    bitrate?: string | number
  } & RequestBaseConfig,
): Promise<Response>

export function comment_info_list(
  params: {
    ids?: string
    type?: CommentType
  } & RequestBaseConfig,
): Promise<Response>

export function comment_report(
  params: {
    id: string | number
    cid: string | number
    reason: string | number
  } & RequestBaseConfig,
): Promise<Response>

export function creator_authinfo_get(
  params: RequestBaseConfig,
): Promise<Response>

export function dj_difm_all_style_channel(
  params: {
    sources?: string
  } & RequestBaseConfig,
): Promise<Response>

export function dj_difm_channel_subscribe(
  params: {
    id: string | number
  } & RequestBaseConfig,
): Promise<Response>

export function dj_difm_channel_unsubscribe(
  params: {
    id: string | number
  } & RequestBaseConfig,
): Promise<Response>

export function dj_difm_playing_tracks_list(
  params: {
    channelId: string | number
    limit?: string | number
    source?: string | number
  } & RequestBaseConfig,
): Promise<Response>

export function dj_difm_subscribe_channels_get(
  params: {
    sources?: string
  } & RequestBaseConfig,
): Promise<Response>

export function fanscenter_basicinfo_age_get(
  params: RequestBaseConfig,
): Promise<Response>

export function fanscenter_basicinfo_gender_get(
  params: RequestBaseConfig,
): Promise<Response>

export function fanscenter_basicinfo_province_get(
  params: RequestBaseConfig,
): Promise<Response>

export function fanscenter_overview_get(
  params: RequestBaseConfig,
): Promise<Response>

export function fanscenter_trend_list(
  params: {
    startTime?: string | number
    endTime?: string | number
    type?: string | number
  } & RequestBaseConfig,
): Promise<Response>

export function lbs_city_code(
  params: {
    bizCode?: string
  } & RequestBaseConfig,
): Promise<Response>

export function listen_data_realtime_report(
  params: {
    type?: string
  } & RequestBaseConfig,
): Promise<Response>

export function listen_data_report(
  params: {
    type?: string
    endTime?: string | number
  } & RequestBaseConfig,
): Promise<Response>

export function listen_data_song_play_rank(
  params: {
    type?: string
    endTime?: string | number
  } & RequestBaseConfig,
): Promise<Response>

export function listen_data_today_song(
  params: RequestBaseConfig,
): Promise<Response>

export function listen_data_total(params: RequestBaseConfig): Promise<Response>

export function listen_data_year_report(
  params: RequestBaseConfig,
): Promise<Response>

export function listentogether_accept(
  params: {
    roomId: string | number
    inviterId: string | number
  } & RequestBaseConfig,
): Promise<Response>

export function listentogether_end(
  params: {
    roomId: string | number
  } & RequestBaseConfig,
): Promise<Response>

export function listentogether_heatbeat(
  params: {
    roomId: string | number
    songId: string | number
    playStatus: string | number
    progress: string | number
  } & RequestBaseConfig,
): Promise<Response>

export function listentogether_play_command(
  params: {
    roomId: string | number
    commandType: string | number
    progress?: string | number
    playStatus: string | number
    formerSongId: string | number
    targetSongId: string | number
    clientSeq: string | number
  } & RequestBaseConfig,
): Promise<Response>

export function listentogether_room_check(
  params: {
    roomId: string | number
  } & RequestBaseConfig,
): Promise<Response>

export function listentogether_room_create(
  params: RequestBaseConfig,
): Promise<Response>

export function listentogether_sync_list_command(
  params: {
    roomId: string | number
    commandType: string | number
    userId: string | number
    version: string | number
    randomList: string
    displayList: string
  } & RequestBaseConfig,
): Promise<Response>

export function listentogether_sync_playlist_get(
  params: {
    roomId: string | number
  } & RequestBaseConfig,
): Promise<Response>

export function mlog_music_rcmd(
  params: {
    mvid?: string | number
    songid?: string | number
    limit?: string | number
  } & RequestBaseConfig,
): Promise<Response>

export function music_first_listen_info(
  params: {
    id: string | number
  } & RequestBaseConfig,
): Promise<Response>

export function personal_fm_mode(
  params: {
    mode: string
    submode?: string
    limit?: string | number
  } & RequestBaseConfig,
): Promise<Response>

export function playlist_category_list(
  params: {
    cat?: string
    limit?: string | number
  } & RequestBaseConfig,
): Promise<Response>

export function playlist_detail_rcmd_get(
  params: {
    id: string | number
  } & RequestBaseConfig,
): Promise<Response>

export function playlist_import_name_task_create(
  params: {
    local?: string
    importStarPlaylist?: boolean
    ['name']?: string
    ['description']?: string
    ['id']?: string | number
    ['url']?: string
  } & RequestBaseConfig,
): Promise<Response>

export function playlist_import_task_status(
  params: {
    id: string | number
  } & RequestBaseConfig,
): Promise<Response>

export function playlist_privacy(
  params: {
    id: string | number
  } & RequestBaseConfig,
): Promise<Response>

export function playmode_song_vector(
  params: {
    ids: string
  } & RequestBaseConfig,
): Promise<Response>

export function radio_sport_get(
  params: {
    bpm?: string | number
  } & RequestBaseConfig,
): Promise<Response>

export function recent_listen_list(params: RequestBaseConfig): Promise<Response>

export function recommend_songs_dislike(
  params: {
    id: string | number
  } & RequestBaseConfig,
): Promise<Response>

export function register_anonimous(params: RequestBaseConfig): Promise<Response>

export function sati_resource_list(
  params: {
    tag: string
  } & RequestBaseConfig,
): Promise<Response>

export function sati_resource_list_more(
  params: {
    id: string | number
  } & RequestBaseConfig,
): Promise<Response>

export function sati_resource_sub(
  params: {
    id: string | number
    cancel?: string | boolean
  } & RequestBaseConfig,
): Promise<Response>

export function sati_resource_sub_list(
  params: RequestBaseConfig,
): Promise<Response>

export function sati_tag_list(params: RequestBaseConfig): Promise<Response>

export function sati_timescene_resources_get(
  params: RequestBaseConfig,
): Promise<Response>

export function search_match(
  params: {
    title?: string
    album?: string
    artist?: string
    duration?: string | number
    md5?: string
  } & RequestBaseConfig,
): Promise<Response>

export function search_suggest_pc(
  params: {
    keyword: string
  } & RequestBaseConfig,
): Promise<Response>

export function send_album(
  params: {
    id: string | number
    msg?: string
    user_ids: string
  } & RequestBaseConfig,
): Promise<Response>

export function send_song(
  params: {
    id: string | number
    msg?: string
    user_ids: string
  } & RequestBaseConfig,
): Promise<Response>

export function song_chorus(
  params: {
    id: string | number
  } & RequestBaseConfig,
): Promise<Response>

export function song_cloud_download(
  params: { id: string | number } & RequestBaseConfig,
): Promise<Response>

export function song_creators(
  params: {
    id: string | number
  } & RequestBaseConfig,
): Promise<Response>

export function song_downlist(
  params: MultiPageConfig & RequestBaseConfig,
): Promise<Response>

export function song_download_url_v1(
  params: {
    id: string | number
    level: SoundQualityType
  } & RequestBaseConfig,
): Promise<Response>

export function song_dynamic_cover(
  params: {
    id: string | number
  } & RequestBaseConfig,
): Promise<Response>

export function song_like(
  params: {
    id: string | number
    like?: string | boolean
    uid?: string | number
  } & RequestBaseConfig,
): Promise<Response>

export function song_like_check(
  params: {
    ids: string
  } & RequestBaseConfig,
): Promise<Response>

export function song_lyrics_mark(
  params: {
    id: string | number
  } & RequestBaseConfig,
): Promise<Response>

export function song_lyrics_mark_add(
  params: {
    id: string | number
    markId?: string
    data?: string
  } & RequestBaseConfig,
): Promise<Response>

export function song_lyrics_mark_del(
  params: {
    id: string | number
  } & RequestBaseConfig,
): Promise<Response>

export function song_lyrics_mark_user_page(
  params: MultiPageConfig & RequestBaseConfig,
): Promise<Response>

export function song_monthdownlist(
  params: MultiPageConfig & RequestBaseConfig,
): Promise<Response>

export function song_music_detail(
  params: {
    id: string | number
  } & RequestBaseConfig,
): Promise<Response>

export function song_red_count(
  params: {
    id: string | number
  } & RequestBaseConfig,
): Promise<Response>

export function song_singledownlist(
  params: MultiPageConfig & RequestBaseConfig,
): Promise<Response>

export function song_url_match(
  params: {
    id: string | number
    source?: string
  } & RequestBaseConfig,
): Promise<Response>

export function song_url_ncmget(params: RequestBaseConfig): Promise<Response>

export function song_url_v1_302(
  params: {
    id: string | number
    level: SoundQualityType
  } & RequestBaseConfig,
): Promise<Response>

export function starpick_comments_summary(
  params: RequestBaseConfig,
): Promise<Response>

export function summary_annual(
  params: {
    year: string
  } & RequestBaseConfig,
): Promise<Response>

export function threshold_detail_get(
  params: RequestBaseConfig,
): Promise<Response>

export function thinktank_audit_resource_detail(
  params: { type?: string | number } & RequestBaseConfig,
): Promise<Response>

export function thinktank_audit_resource_update(
  params: {
    type?: string | number
    taskId: string | number
    judgement: string | number
  } & RequestBaseConfig,
): Promise<Response>

export function toplist_detail_v2(params: RequestBaseConfig): Promise<Response>

export function ugc_album_get(
  params: {
    id: string | number
  } & RequestBaseConfig,
): Promise<Response>

export function ugc_artist_get(
  params: {
    id: string | number
  } & RequestBaseConfig,
): Promise<Response>

export function ugc_artist_search(
  params: {
    keyword: string
    limit?: string | number
  } & RequestBaseConfig,
): Promise<Response>

export function ugc_detail(
  params: {
    auditStatus?: string
    type?: string | number
    sortBy?: string
    order?: string
  } & MultiPageConfig &
    RequestBaseConfig,
): Promise<Response>

export function ugc_mv_get(
  params: {
    id: string | number
  } & RequestBaseConfig,
): Promise<Response>

export function ugc_song_get(
  params: {
    id: string | number
  } & RequestBaseConfig,
): Promise<Response>

export function ugc_user_devote(params: RequestBaseConfig): Promise<Response>

export function user_detail_new(
  params: {
    uid: string | number
  } & RequestBaseConfig,
): Promise<Response>

export function user_follow_mixed(
  params: {
    size?: string | number
    cursor?: string | number
    scene?: string | number
  } & RequestBaseConfig,
): Promise<Response>

export function user_medal(
  params: {
    uid: string | number
  } & RequestBaseConfig,
): Promise<Response>

export function user_mutualfollow_get(
  params: {
    uid: string | number
  } & RequestBaseConfig,
): Promise<Response>

export function user_playlist_collect(
  params: {
    uid: string | number
  } & MultiPageConfig &
    RequestBaseConfig,
): Promise<Response>

export function user_playlist_create(
  params: {
    uid: string | number
  } & MultiPageConfig &
    RequestBaseConfig,
): Promise<Response>

export function user_social_status(
  params: {
    uid: string | number
  } & RequestBaseConfig,
): Promise<Response>

export function user_social_status_edit(
  params: {
    type: string | number
    iconUrl?: string
    content?: string
    actionUrl?: string
  } & RequestBaseConfig,
): Promise<Response>

export function user_social_status_rcmd(
  params: RequestBaseConfig,
): Promise<Response>

export function user_social_status_support(
  params: RequestBaseConfig,
): Promise<Response>

export function verify_getQr(
  params: {
    vid: string | number
    type: string | number
    token: string
    evid: string
    sign: string
  } & RequestBaseConfig,
): Promise<Response>

export function verify_qrcodestatus(
  params: {
    qr: string
  } & RequestBaseConfig,
): Promise<Response>

export function vip_sign(params: RequestBaseConfig): Promise<Response>

export function vip_sign_detail(
  params: { timestamp: string | number } & RequestBaseConfig,
): Promise<Response>

export function vip_sign_history(
  params: { type?: string | number } & RequestBaseConfig,
): Promise<Response>

export function vip_sign_info(params: RequestBaseConfig): Promise<Response>

export function vip_tasks_v1(
  params: {
    id?: string | number
  } & RequestBaseConfig,
): Promise<Response>

export function voice_detail(
  params: {
    id: string | number
  } & RequestBaseConfig,
): Promise<Response>

export function voice_upload(
  params: {
    songFile: {
      name: string
      data: string | Buffer
    }
    imgFile?: {
      name: string
      data: string | Buffer
    }
    voiceListId: string | number
    coverImgId?: string | number
    categoryId: string | number
    secondCategoryId: string | number
    description: string
    songName?: string
    privacy?: string | number
    publishTime?: string | number
    autoPublish?: string | number
    autoPublishText?: string
    orderNo?: string | number
    composedSongs?: string
  } & RequestBaseConfig,
): Promise<Response>

export function voicelist_detail(
  params: {
    id: string | number
  } & RequestBaseConfig,
): Promise<Response>

export function voicelist_list(
  params: {
    voiceListId: string | number
  } & MultiPageConfig &
    RequestBaseConfig,
): Promise<Response>

export function voicelist_my_created(
  params: {
    limit?: string | number
  } & RequestBaseConfig,
): Promise<Response>

export function voicelist_search(
  params: {
    keyword?: string
    limit?: string | number
    offset?: string | number
  } & RequestBaseConfig,
): Promise<Response>

export function voicelist_trans(
  params: {
    radioId?: string | number
    programId?: string | number
    position?: string | number
  } & MultiPageConfig &
    RequestBaseConfig,
): Promise<Response>

export function fans_group_detail(
  params: {
    groupId: string
    scene?: string
  } & RequestBaseConfig,
): Promise<Response>

export function fans_group_feed_recommend(
  params: {
    fansGroupId: string
    cursor?: string
    size?: string | number
  } & RequestBaseConfig,
): Promise<Response>

export function fans_group_user_groups(
  params?: RequestBaseConfig,
): Promise<Response>

export function fans_group_user_group_detail(
  params: {
    groupId: string | number
  } & RequestBaseConfig,
): Promise<Response>
